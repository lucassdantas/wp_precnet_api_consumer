<?php 
//AMDG